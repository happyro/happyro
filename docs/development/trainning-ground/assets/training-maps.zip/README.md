# 三张训练场官方资源

已找回 `tra_fild01`、`tra_fild02`、`tra_fild03`。资源来自 Gravity kRO 官方补丁服务器；原有 2021 运行资源中的已存在依赖作为副本一并收录。没有修改官方输入、运行资源、产品代码或服务器状态。

## 官方来源

补丁列表：https://ropatch.gnjoy.com/PatchInfo/patch2.txt

- https://ropatch.gnjoy.com/Patch/2021-11-17_live_data_493_498_1636621550.gpf
- https://ropatch.gnjoy.com/Patch/2022-09-28_live_data_1043_1043_1663831766.gpf
- https://ropatch.gnjoy.com/Patch/2023-08-02_live_data_1433_1440_1690420988.gpf
- https://ropatch.gnjoy.com/Patch/2024-05-16_live_data_1981_1982_1715224936.gpf
- https://ropatch.gnjoy.com/Patch/2025-10-15_live_client_2799_2800_1760061430.gpf
- https://ropatch.gnjoy.com/Patch/2025-10-15_live_client_2812_2812_1760510532.gpf

## 文件与验证

- 三个 `.rsw` 和三个 `.gat` 均为官方原始文件。
- 三张世界文件均引用 `tra_fild02.gnd` 与 `tra_fild02.gat`；这是官方资源的真实结构，未添加别名或替代地图。
- `.rsw` 版本为 2.7，地面 `.gnd` 版本为 1.9；地面为 110 × 110，碰撞网格为 220 × 220。
- 当前客户端的 World、Ground、Model 解析器已成功解析三张地图和 33 个独立模型。每张地图含 1020 个模型实例。
- 已核对 85 个模型、地面/模型纹理和地图 Lua 特效贴图依赖，缺失为 0。
- 附带三个地图的 Lua 特效文件和官方 `tra_fild02.bmp` 小地图。
- 每个文件的 SHA-256、长度、来源补丁或现有运行资源来源记录在 `manifest.json`。

## 尚未执行

未安装到 Gateway，未重新生成地图支持清单或地图图鉴，未调整小地图关联，未进行真实游戏渲染或训练 NPC 交互验收。此包是找回并完成结构/依赖验证的资源，不代表线上问题已经修复。

## 本机应用结果（2026-10-23）

已将 46 个官方补充文件安装到 `inputs/runtime/kro-20211105/client`，并逐项核对源、目标及 Gateway HTTP 内容哈希。三张地图已通过无头 MapViewer 的实际加载和渲染，无资源 404 或页面错误。地图支持清单、中文名称、小地图和后台地图目录已更新；PWA 完整构建并验证入口产物。仅重启 API 以刷新地图目录，未重启游戏服务。

原 `~/Downloads/happyro-resources-20261022.tar.gz` 没有重打，仍是补丁前版本。地图包来源 ZIP 保留为最初交付内容，当前安装及验收证据另见 `install-report.json`、`http-verification.json`、`browser-verification.json` 与三张渲染截图。

## 完整场内验收补充

已补充 26 个官方假人 SPR/ACT；运行目录共安装 72 个补充文件。三场实际教官对话、传送、重登、假人战斗、仓库和场内 NPC 已完成无头实机验收。假人外观须配合当前客户端的 143 个官方映射；资源包不能替代客户端代码部署。详见根仓库 docs/game-data/training-grounds.md。
